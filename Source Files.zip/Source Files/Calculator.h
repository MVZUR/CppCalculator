#pragma once

#include <cmath>
#include <vector>
#include <string>

namespace Calculator {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Calculator
	/// </summary>
	public ref class Calculator : public System::Windows::Forms::Form
	{

	public:
		Calculator(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Calculator()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^ textBox1;
	protected:

	protected:

	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;


	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button4;

	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::Button^ button7;
	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Button^ button9;
	private: System::Windows::Forms::Button^ button10;
	private: System::Windows::Forms::Button^ button11;
	private: System::Windows::Forms::Button^ button12;
	private: System::Windows::Forms::Button^ button13;
	private: System::Windows::Forms::Button^ button14;
	private: System::Windows::Forms::Button^ button15;
	private: System::Windows::Forms::Button^ button16;
	private: System::Windows::Forms::Button^ button17;
	private: System::Windows::Forms::Button^ button18;
	private: System::Windows::Forms::Button^ button19;
	private: System::Windows::Forms::Button^ button20;
	private: System::Windows::Forms::Button^ button21;
	private: System::Windows::Forms::Button^ button22;
	private: System::Windows::Forms::Button^ button23;
	private: System::Windows::Forms::Button^ button24;
	private: System::Windows::Forms::Button^ button25;
	private: System::Windows::Forms::Button^ button26;
	private: System::Windows::Forms::Button^ button27;
	private: System::Windows::Forms::Button^ button28;
	private: System::Windows::Forms::Button^ button29;
	private: System::Windows::Forms::Button^ button30;

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->button12 = (gcnew System::Windows::Forms::Button());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->button16 = (gcnew System::Windows::Forms::Button());
			this->button17 = (gcnew System::Windows::Forms::Button());
			this->button18 = (gcnew System::Windows::Forms::Button());
			this->button19 = (gcnew System::Windows::Forms::Button());
			this->button20 = (gcnew System::Windows::Forms::Button());
			this->button21 = (gcnew System::Windows::Forms::Button());
			this->button22 = (gcnew System::Windows::Forms::Button());
			this->button23 = (gcnew System::Windows::Forms::Button());
			this->button24 = (gcnew System::Windows::Forms::Button());
			this->button25 = (gcnew System::Windows::Forms::Button());
			this->button26 = (gcnew System::Windows::Forms::Button());
			this->button27 = (gcnew System::Windows::Forms::Button());
			this->button28 = (gcnew System::Windows::Forms::Button());
			this->button29 = (gcnew System::Windows::Forms::Button());
			this->button30 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// textBox1
			// 
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 48, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->textBox1->Location = System::Drawing::Point(11, 12);
			this->textBox1->Multiline = true;
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(286, 79);
			this->textBox1->TabIndex = 0;
			this->textBox1->Text = L"0";
			this->textBox1->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &Calculator::textBox1_TextChanged);
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button1->Location = System::Drawing::Point(11, 104);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(70, 50);
			this->button1->TabIndex = 1;
			this->button1->Text = L"set";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Calculator::SetList);
			// 
			// button2
			// 
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button2->Location = System::Drawing::Point(83, 104);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(70, 50);
			this->button2->TabIndex = 1;
			this->button2->Text = L"CE";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Calculator::ClearEnter);
			// 
			// button3
			// 
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button3->Location = System::Drawing::Point(155, 104);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(70, 50);
			this->button3->TabIndex = 1;
			this->button3->Text = L"C";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Calculator::ClearAll);
			// 
			// button4
			// 
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button4->Location = System::Drawing::Point(227, 104);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(70, 50);
			this->button4->TabIndex = 1;
			this->button4->Text = L"�";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Calculator::EnterOperator);
			// 
			// button5
			// 
			this->button5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button5->Location = System::Drawing::Point(227, 156);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(70, 50);
			this->button5->TabIndex = 3;
			this->button5->Text = L"�";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Calculator::EnterOperator);
			// 
			// button6
			// 
			this->button6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button6->Location = System::Drawing::Point(155, 156);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(70, 50);
			this->button6->TabIndex = 4;
			this->button6->Text = L"9";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Calculator::EnterNumber);
			// 
			// button7
			// 
			this->button7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button7->Location = System::Drawing::Point(83, 156);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(70, 50);
			this->button7->TabIndex = 5;
			this->button7->Text = L"8";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &Calculator::EnterNumber);
			// 
			// button8
			// 
			this->button8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button8->Location = System::Drawing::Point(11, 156);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(70, 50);
			this->button8->TabIndex = 6;
			this->button8->Text = L"7";
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &Calculator::EnterNumber);
			// 
			// button9
			// 
			this->button9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button9->Location = System::Drawing::Point(227, 208);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(70, 50);
			this->button9->TabIndex = 7;
			this->button9->Text = L"-";
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &Calculator::EnterOperator);
			// 
			// button10
			// 
			this->button10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button10->Location = System::Drawing::Point(155, 208);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(70, 50);
			this->button10->TabIndex = 8;
			this->button10->Text = L"6";
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &Calculator::EnterNumber);
			// 
			// button11
			// 
			this->button11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button11->Location = System::Drawing::Point(83, 208);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(70, 50);
			this->button11->TabIndex = 9;
			this->button11->Text = L"5";
			this->button11->UseVisualStyleBackColor = true;
			this->button11->Click += gcnew System::EventHandler(this, &Calculator::EnterNumber);
			// 
			// button12
			// 
			this->button12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button12->Location = System::Drawing::Point(11, 208);
			this->button12->Name = L"button12";
			this->button12->Size = System::Drawing::Size(70, 50);
			this->button12->TabIndex = 10;
			this->button12->Text = L"4";
			this->button12->UseVisualStyleBackColor = true;
			this->button12->Click += gcnew System::EventHandler(this, &Calculator::EnterNumber);
			// 
			// button13
			// 
			this->button13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button13->Location = System::Drawing::Point(227, 260);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(70, 50);
			this->button13->TabIndex = 11;
			this->button13->Text = L"+";
			this->button13->UseVisualStyleBackColor = true;
			this->button13->Click += gcnew System::EventHandler(this, &Calculator::EnterOperator);
			// 
			// button14
			// 
			this->button14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button14->Location = System::Drawing::Point(155, 260);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(70, 50);
			this->button14->TabIndex = 12;
			this->button14->Text = L"3";
			this->button14->UseVisualStyleBackColor = true;
			this->button14->Click += gcnew System::EventHandler(this, &Calculator::EnterNumber);
			// 
			// button15
			// 
			this->button15->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button15->Location = System::Drawing::Point(83, 260);
			this->button15->Name = L"button15";
			this->button15->Size = System::Drawing::Size(70, 50);
			this->button15->TabIndex = 13;
			this->button15->Text = L"2";
			this->button15->UseVisualStyleBackColor = true;
			this->button15->Click += gcnew System::EventHandler(this, &Calculator::EnterNumber);
			// 
			// button16
			// 
			this->button16->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button16->Location = System::Drawing::Point(11, 260);
			this->button16->Name = L"button16";
			this->button16->Size = System::Drawing::Size(70, 50);
			this->button16->TabIndex = 14;
			this->button16->Text = L"1";
			this->button16->UseVisualStyleBackColor = true;
			this->button16->Click += gcnew System::EventHandler(this, &Calculator::EnterNumber);
			// 
			// button17
			// 
			this->button17->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button17->Location = System::Drawing::Point(227, 312);
			this->button17->Name = L"button17";
			this->button17->Size = System::Drawing::Size(70, 50);
			this->button17->TabIndex = 15;
			this->button17->Text = L"=";
			this->button17->UseVisualStyleBackColor = true;
			this->button17->Click += gcnew System::EventHandler(this, &Calculator::Equal);
			// 
			// button18
			// 
			this->button18->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button18->Location = System::Drawing::Point(155, 312);
			this->button18->Name = L"button18";
			this->button18->Size = System::Drawing::Size(70, 50);
			this->button18->TabIndex = 16;
			this->button18->Text = L".";
			this->button18->UseVisualStyleBackColor = true;
			this->button18->Click += gcnew System::EventHandler(this, &Calculator::DotClick);
			// 
			// button19
			// 
			this->button19->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button19->Location = System::Drawing::Point(83, 312);
			this->button19->Name = L"button19";
			this->button19->Size = System::Drawing::Size(70, 50);
			this->button19->TabIndex = 17;
			this->button19->Text = L"0";
			this->button19->UseVisualStyleBackColor = true;
			this->button19->Click += gcnew System::EventHandler(this, &Calculator::EnterNumber);
			// 
			// button20
			// 
			this->button20->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button20->Location = System::Drawing::Point(11, 312);
			this->button20->Name = L"button20";
			this->button20->Size = System::Drawing::Size(70, 50);
			this->button20->TabIndex = 18;
			this->button20->Text = L"%";
			this->button20->UseVisualStyleBackColor = true;
			this->button20->Click += gcnew System::EventHandler(this, &Calculator::MakePerCent);
			// 
			// button21
			// 
			this->button21->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button21->Location = System::Drawing::Point(12, 156);
			this->button21->Name = L"button21";
			this->button21->Size = System::Drawing::Size(0, 0);
			this->button21->TabIndex = 19;
			this->button21->Text = L"float";
			this->button21->UseVisualStyleBackColor = true;
			this->button21->Click += gcnew System::EventHandler(this, &Calculator::float_click);
			// 
			// button22
			// 
			this->button22->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button22->Location = System::Drawing::Point(12, 208);
			this->button22->Name = L"button22";
			this->button22->Size = System::Drawing::Size(0, 0);
			this->button22->TabIndex = 20;
			this->button22->Text = L"bin";
			this->button22->UseVisualStyleBackColor = true;
			this->button22->Click += gcnew System::EventHandler(this, &Calculator::bin_click);
			// 
			// button23
			// 
			this->button23->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button23->Location = System::Drawing::Point(12, 260);
			this->button23->Name = L"button23";
			this->button23->Size = System::Drawing::Size(0, 0);
			this->button23->TabIndex = 21;
			this->button23->Text = L"oct";
			this->button23->UseVisualStyleBackColor = true;
			this->button23->Click += gcnew System::EventHandler(this, &Calculator::oct_click);
			// 
			// button24
			// 
			this->button24->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button24->Location = System::Drawing::Point(12, 315);
			this->button24->Name = L"button24";
			this->button24->Size = System::Drawing::Size(0, 0);
			this->button24->TabIndex = 22;
			this->button24->Text = L"hex";
			this->button24->UseVisualStyleBackColor = true;
			this->button24->Click += gcnew System::EventHandler(this, &Calculator::hex_click);
			// 
			// button25
			// 
			this->button25->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 15, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button25->Location = System::Drawing::Point(227, 104);
			this->button25->Name = L"button25";
			this->button25->Size = System::Drawing::Size(0, 0);
			this->button25->TabIndex = 23;
			this->button25->Text = L"A";
			this->button25->UseVisualStyleBackColor = true;
			this->button25->Click += gcnew System::EventHandler(this, &Calculator::ABCDEF_Click);
			// 
			// button26
			// 
			this->button26->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 15, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button26->Location = System::Drawing::Point(227, 156);
			this->button26->Name = L"button26";
			this->button26->Size = System::Drawing::Size(0, 0);
			this->button26->TabIndex = 24;
			this->button26->Text = L"B";
			this->button26->UseVisualStyleBackColor = true;
			this->button26->Click += gcnew System::EventHandler(this, &Calculator::ABCDEF_Click);
			// 
			// button27
			// 
			this->button27->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 15, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button27->Location = System::Drawing::Point(227, 208);
			this->button27->Name = L"button27";
			this->button27->Size = System::Drawing::Size(0, 0);
			this->button27->TabIndex = 25;
			this->button27->Text = L"C";
			this->button27->UseVisualStyleBackColor = true;
			this->button27->Click += gcnew System::EventHandler(this, &Calculator::ABCDEF_Click);
			// 
			// button28
			// 
			this->button28->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 15, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button28->Location = System::Drawing::Point(227, 260);
			this->button28->Name = L"button28";
			this->button28->Size = System::Drawing::Size(0, 0);
			this->button28->TabIndex = 26;
			this->button28->Text = L"D";
			this->button28->UseVisualStyleBackColor = true;
			this->button28->Click += gcnew System::EventHandler(this, &Calculator::ABCDEF_Click);
			// 
			// button29
			// 
			this->button29->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 15, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button29->Location = System::Drawing::Point(227, 312);
			this->button29->Name = L"button29";
			this->button29->Size = System::Drawing::Size(0, 0);
			this->button29->TabIndex = 27;
			this->button29->Text = L"E";
			this->button29->UseVisualStyleBackColor = true;
			this->button29->Click += gcnew System::EventHandler(this, &Calculator::ABCDEF_Click);
			// 
			// button30
			// 
			this->button30->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 15, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(238)));
			this->button30->Location = System::Drawing::Point(155, 312);
			this->button30->Name = L"button30";
			this->button30->Size = System::Drawing::Size(0, 0);
			this->button30->TabIndex = 28;
			this->button30->Text = L"F";
			this->button30->UseVisualStyleBackColor = true;
			this->button30->Click += gcnew System::EventHandler(this, &Calculator::ABCDEF_Click);
			// 
			// Calculator
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(309, 372);
			this->Controls->Add(this->button30);
			this->Controls->Add(this->button29);
			this->Controls->Add(this->button28);
			this->Controls->Add(this->button27);
			this->Controls->Add(this->button26);
			this->Controls->Add(this->button25);
			this->Controls->Add(this->button24);
			this->Controls->Add(this->button23);
			this->Controls->Add(this->button22);
			this->Controls->Add(this->button21);
			this->Controls->Add(this->button17);
			this->Controls->Add(this->button18);
			this->Controls->Add(this->button19);
			this->Controls->Add(this->button20);
			this->Controls->Add(this->button13);
			this->Controls->Add(this->button14);
			this->Controls->Add(this->button15);
			this->Controls->Add(this->button16);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->button10);
			this->Controls->Add(this->button11);
			this->Controls->Add(this->button12);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->textBox1);
			this->Name = L"Calculator";
			this->Text = L"Calculator";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

		// podstawowe zmienne potrzebne do pracy kalkulatora
		double firstDigit{};
		double secondDigit{};
		double value{};
		double percent{};
		double result{};
		double step{};
		double digitLimit{};
		double equalClick{};
		double set{};

		// tryb pracy
		double mode = 1;	

		// sekcja pracy w trybie bin oct hex
		int bin = 0;
		int oct = 0;
		long int hex = 0;
		int dec = 0;
		int rem = 0;
		int i = 0;

		// zmienne do kodowania liczb w systemie hex
		long int hex0 = 0;
		long int hex1 = 0;
		long int hex2 = 0;
		long int hex3 = 0;
		long int hex4 = 0;
		long int hex5 = 0;
		long int hex6 = 0;


		// zapisywanie tekstu ----------

		String^ operators;

		String^ previousText;
		String^ previousText1;
		String^ previousText2;
		String^ previousText3;
		String^ previousText4;
		String^ previousText5;
		String^ previousText6;

		String^ currentText = "0";
		String^ currentText1 = "0";
		String^ currentText2 = "0";
		String^ currentText3 = "0";
		String^ currentText4 = "0";
		String^ currentText5 = "0";
		String^ currentText6 = "0";

		String^ hex_str0 = "0";
		String^ hex_str1 = "0";
		String^ hex_str2 = "0";
		String^ hex_str3 = "0";
		String^ hex_str4 = "0";
		String^ hex_str5 = "0";
		String^ hex_str6 = "0";

		// ----------------------------
		


		void save_bit(int x, String^ y)	// zapisywanie bitow w systemie binarnym
		{
			if (x == 0)
			{
				previousText = y;
			}

			if (x == 1)
			{
				previousText1 = y;
			}

			if (x == 2)
			{
				previousText2 = y;
			}

			if (x == 3)
			{
				previousText3 = y;
			}

			if (x == 4)
			{
				previousText4 = y;
			}

			if (x == 5)
			{
				previousText5 = y;
			}

			if (x == 6)
			{
				previousText6 = y;
			}
		}





		void clear_zeros(void)	// usuwanie zer przed pierwsza cyfra znaczaca
		{
			if (previousText6 == "0" & !(previousText5 == "0"))
			{
				previousText6 = "";
			}
			else if (previousText6 == "0" & previousText5 == "0" & !(previousText4 == "0"))
			{
				previousText6 = "";
				previousText5 = "";
			}
			else if (previousText6 == "0" & previousText5 == "0" & previousText4 == "0" & !(previousText3 == "0"))
			{
				previousText6 = "";
				previousText5 = "";
				previousText4 = "";
			}
			else if (previousText6 == "0" & previousText5 == "0" & previousText4 == "0" & previousText3 == "0" & !(previousText2 == "0"))
			{
				previousText6 = "";
				previousText5 = "";
				previousText4 = "";
				previousText3 = "";
			}
			else if (previousText6 == "0" & previousText5 == "0" & previousText4 == "0" & previousText3 == "0" & previousText2 == "0" & !(previousText1 == "0"))
			{
				previousText6 = "";
				previousText5 = "";
				previousText4 = "";
				previousText3 = "";
				previousText2 = "";
			}
			else if (previousText6 == "0" & previousText5 == "0" & previousText4 == "0" & previousText3 == "0" & previousText2 == "0" & previousText1 == "0" & !(previousText == "0"))
			{
				previousText6 = "";
				previousText5 = "";
				previousText4 = "";
				previousText3 = "";
				previousText2 = "";
				previousText1 = "";
			}
		}





private: System::Void SetList(System::Object^ sender, System::EventArgs^ e) {	// lista z ustawieniami trybow pracy
	
	// wybieranie trybu pracy - dopasowanie mozliwosci i przyciskow kalkulatora

	if (set == 1)
	{
		if (mode == 1)	// tryb decymalny - float
		{
			set = 0;	// zamknij liste
			button2->Size = System::Drawing::Size(70, 50);
			button3->Size = System::Drawing::Size(70, 50);
			button4->Size = System::Drawing::Size(70, 50);
			button5->Size = System::Drawing::Size(70, 50);
			button6->Size = System::Drawing::Size(70, 50);
			button7->Size = System::Drawing::Size(70, 50);
			button8->Size = System::Drawing::Size(70, 50);
			button9->Size = System::Drawing::Size(70, 50);
			button10->Size = System::Drawing::Size(70, 50);
			button11->Size = System::Drawing::Size(70, 50);
			button12->Size = System::Drawing::Size(70, 50);
			button13->Size = System::Drawing::Size(70, 50);
			button14->Size = System::Drawing::Size(70, 50);
			button15->Size = System::Drawing::Size(70, 50);
			button16->Size = System::Drawing::Size(70, 50);
			button17->Size = System::Drawing::Size(70, 50);
			button18->Size = System::Drawing::Size(70, 50);
			button19->Size = System::Drawing::Size(70, 50);
			button20->Size = System::Drawing::Size(70, 50);
			button21->Size = System::Drawing::Size(0, 0);
			button22->Size = System::Drawing::Size(0, 0);
			button23->Size = System::Drawing::Size(0, 0);
			button24->Size = System::Drawing::Size(0, 0);

			button25->Size = System::Drawing::Size(0, 0);
			button26->Size = System::Drawing::Size(0, 0);
			button27->Size = System::Drawing::Size(0, 0);
			button28->Size = System::Drawing::Size(0, 0);
			button29->Size = System::Drawing::Size(0, 0);
			button30->Size = System::Drawing::Size(0, 0);

			ClientSize = System::Drawing::Size(309, 372);

			button4->Location = System::Drawing::Point(227, 104);
			button5->Location = System::Drawing::Point(227, 156);
			button9->Location = System::Drawing::Point(227, 208);
			button13->Location = System::Drawing::Point(227, 260);
			button17->Location = System::Drawing::Point(227, 312);

			textBox1->Location = System::Drawing::Point(11, 12);
		}

		else if (mode == 2)		// tryb binarny
		{
			set = 0;	// zamknij liste
			button2->Size = System::Drawing::Size(70, 50);
			button3->Size = System::Drawing::Size(70, 50);
			button4->Size = System::Drawing::Size(70, 50);
			button5->Size = System::Drawing::Size(70, 50);
			button6->Size = System::Drawing::Size(0, 0);
			button7->Size = System::Drawing::Size(0, 0);
			button8->Size = System::Drawing::Size(0, 0);
			button9->Size = System::Drawing::Size(70, 50);
			button10->Size = System::Drawing::Size(0, 0);
			button11->Size = System::Drawing::Size(0, 0);
			button12->Size = System::Drawing::Size(0, 0);
			button13->Size = System::Drawing::Size(70, 50);
			button14->Size = System::Drawing::Size(0, 0);
			button15->Size = System::Drawing::Size(0, 0);
			button16->Size = System::Drawing::Size(70, 50);
			button17->Size = System::Drawing::Size(70, 50);
			button18->Size = System::Drawing::Size(0, 0);
			button19->Size = System::Drawing::Size(70, 50);
			button20->Size = System::Drawing::Size(0, 0);
			button21->Size = System::Drawing::Size(0, 0);
			button22->Size = System::Drawing::Size(0, 0);
			button23->Size = System::Drawing::Size(0, 0);
			button24->Size = System::Drawing::Size(0, 0);

			button25->Size = System::Drawing::Size(0, 0);
			button26->Size = System::Drawing::Size(0, 0);
			button27->Size = System::Drawing::Size(0, 0);
			button28->Size = System::Drawing::Size(0, 0);
			button29->Size = System::Drawing::Size(0, 0);
			button30->Size = System::Drawing::Size(0, 0);

			ClientSize = System::Drawing::Size(309, 372);

			button4->Location = System::Drawing::Point(227, 104);
			button5->Location = System::Drawing::Point(227, 156);
			button9->Location = System::Drawing::Point(227, 208);
			button13->Location = System::Drawing::Point(227, 260);
			button17->Location = System::Drawing::Point(227, 312);

			textBox1->Location = System::Drawing::Point(11, 12);
		}

		else if (mode == 3)		// tryb oktagonalny
		{
			set = 0;	// zamknij liste
			button2->Size = System::Drawing::Size(70, 50);
			button3->Size = System::Drawing::Size(70, 50);
			button4->Size = System::Drawing::Size(70, 50);
			button5->Size = System::Drawing::Size(70, 50);
			button6->Size = System::Drawing::Size(0, 0);
			button7->Size = System::Drawing::Size(0, 0);
			button8->Size = System::Drawing::Size(70, 50);
			button9->Size = System::Drawing::Size(70, 50);
			button10->Size = System::Drawing::Size(70, 50);
			button11->Size = System::Drawing::Size(70, 50);
			button12->Size = System::Drawing::Size(70, 50);
			button13->Size = System::Drawing::Size(70, 50);
			button14->Size = System::Drawing::Size(70, 50);
			button15->Size = System::Drawing::Size(70, 50);
			button16->Size = System::Drawing::Size(70, 50);
			button17->Size = System::Drawing::Size(70, 50);
			button18->Size = System::Drawing::Size(0, 0);
			button19->Size = System::Drawing::Size(70, 50);
			button20->Size = System::Drawing::Size(0, 0);
			button21->Size = System::Drawing::Size(0, 0);
			button22->Size = System::Drawing::Size(0, 0);
			button23->Size = System::Drawing::Size(0, 0);
			button24->Size = System::Drawing::Size(0, 0);

			button25->Size = System::Drawing::Size(0, 0);
			button26->Size = System::Drawing::Size(0, 0);
			button27->Size = System::Drawing::Size(0, 0);
			button28->Size = System::Drawing::Size(0, 0);
			button29->Size = System::Drawing::Size(0, 0);
			button30->Size = System::Drawing::Size(0, 0);

			ClientSize = System::Drawing::Size(309, 372);

			button4->Location = System::Drawing::Point(227, 104);
			button5->Location = System::Drawing::Point(227, 156);
			button9->Location = System::Drawing::Point(227, 208);
			button13->Location = System::Drawing::Point(227, 260);
			button17->Location = System::Drawing::Point(227, 312);

			textBox1->Location = System::Drawing::Point(11, 12);
		}

		if (mode == 4)	// tryb heksadecymalny
		{
			set = 0;	// zamknij liste
			button2->Size = System::Drawing::Size(70, 50);
			button3->Size = System::Drawing::Size(70, 50);
			button4->Size = System::Drawing::Size(70, 50);
			button5->Size = System::Drawing::Size(70, 50);
			button6->Size = System::Drawing::Size(70, 50);
			button7->Size = System::Drawing::Size(70, 50);
			button8->Size = System::Drawing::Size(70, 50);
			button9->Size = System::Drawing::Size(70, 50);
			button10->Size = System::Drawing::Size(70, 50);
			button11->Size = System::Drawing::Size(70, 50);
			button12->Size = System::Drawing::Size(70, 50);
			button13->Size = System::Drawing::Size(70, 50);
			button14->Size = System::Drawing::Size(70, 50);
			button15->Size = System::Drawing::Size(70, 50);
			button16->Size = System::Drawing::Size(70, 50);
			button17->Size = System::Drawing::Size(70, 50);
			button18->Size = System::Drawing::Size(70, 50);
			button19->Size = System::Drawing::Size(70, 50);
			button20->Size = System::Drawing::Size(0, 0);
			button21->Size = System::Drawing::Size(0, 0);
			button22->Size = System::Drawing::Size(0, 0);
			button23->Size = System::Drawing::Size(0, 0);
			button24->Size = System::Drawing::Size(0, 0);

			button25->Size = System::Drawing::Size(70, 50);
			button26->Size = System::Drawing::Size(70, 50);
			button27->Size = System::Drawing::Size(70, 50);
			button28->Size = System::Drawing::Size(70, 50);
			button29->Size = System::Drawing::Size(70, 50);
			button30->Size = System::Drawing::Size(70, 50);

			ClientSize = System::Drawing::Size(380, 372);

			button4->Location = System::Drawing::Point(299, 104);
			button5->Location = System::Drawing::Point(299, 156);
			button9->Location = System::Drawing::Point(299, 208);
			button13->Location = System::Drawing::Point(299, 260);
			button17->Location = System::Drawing::Point(299, 312);

			textBox1->Location = System::Drawing::Point(46, 12);
		}


	}

	else set = 1;	// znacznik otwarcia listy

	if (set == 1)	// otworz liste
	{
		button2->Size = System::Drawing::Size(0, 0);
		button3->Size = System::Drawing::Size(0, 0);
		button4->Size = System::Drawing::Size(0, 0);
		button5->Size = System::Drawing::Size(0, 0);
		button6->Size = System::Drawing::Size(0, 0);
		button7->Size = System::Drawing::Size(0, 0);
		button8->Size = System::Drawing::Size(0, 0);
		button9->Size = System::Drawing::Size(0, 0);
		button10->Size = System::Drawing::Size(0, 0);
		button11->Size = System::Drawing::Size(0, 0);
		button12->Size = System::Drawing::Size(0, 0);
		button13->Size = System::Drawing::Size(0, 0);
		button14->Size = System::Drawing::Size(0, 0);
		button15->Size = System::Drawing::Size(0, 0);
		button16->Size = System::Drawing::Size(0, 0);
		button17->Size = System::Drawing::Size(0, 0);
		button18->Size = System::Drawing::Size(0, 0);
		button19->Size = System::Drawing::Size(0, 0);
		button20->Size = System::Drawing::Size(0, 0);

		button25->Size = System::Drawing::Size(0, 0);
		button26->Size = System::Drawing::Size(0, 0);
		button27->Size = System::Drawing::Size(0, 0);
		button28->Size = System::Drawing::Size(0, 0);
		button29->Size = System::Drawing::Size(0, 0);
		button30->Size = System::Drawing::Size(0, 0);



		if (mode == 4)	// poszerzone przyciski trybow pracy
		{
			button21->Size = System::Drawing::Size(357, 50);
			button22->Size = System::Drawing::Size(357, 50);
			button23->Size = System::Drawing::Size(357, 50);
			button24->Size = System::Drawing::Size(357, 50);
		}

		else  // standardowe przyciski rybow pracy
		{
			button21->Size = System::Drawing::Size(285, 50);
			button22->Size = System::Drawing::Size(285, 50);
			button23->Size = System::Drawing::Size(285, 50);
			button24->Size = System::Drawing::Size(285, 50);
		}

	}

}

	
private: System::Void EnterNumber(System::Object^ sender, System::EventArgs^ e) {	// wprowadzanie liczb

	Button^ Numbers = safe_cast<Button^>(sender);	// pobieranie danych z przyciskow


	// poczatkowe warunki wprowadzania liczb/znakow ---------------
	if ((textBox1->Text == "0") & !(equalClick == 1))	
	{
		if ((mode == 1) || (mode == 3) || (mode == 4))
		{
			textBox1->Text = Numbers->Text;
		}

		if (mode == 2)
		{
			if (Numbers->Text == "0")
			{
				textBox1->Text = textBox1->Text + Numbers->Text;
			}
			
			else
			{
				textBox1->Text = Numbers->Text;
			}
			
		}
	// -----------------------------------------------------------


		// zapisywanie aktualnych wartosci wprowadzonych znakow
		if (mode == 4)	
		{
			currentText6 = currentText5;
			currentText5 = currentText4;
			currentText4 = currentText3;
			currentText3 = currentText2;
			currentText2 = currentText1;
			currentText1 = currentText;
			currentText = Numbers->Text;
		}
		
	}

	// wprowadzanie kolejnych... liczb/znakow
	else if ((digitLimit < 6) & !(equalClick == 1))
	{
		// zapisywanie wczesniejszych cyfr		
		previousText6 = previousText5;
		previousText5 = previousText4;
		previousText4 = previousText3;
		previousText3 = previousText2;
		previousText2 = previousText1;
		previousText1 = previousText;
		previousText = textBox1->Text;

		// zapisywanie aktualnych cyfr
		currentText6 = currentText5;
		currentText5 = currentText4;
		currentText4 = currentText3;
		currentText3 = currentText2;
		currentText2 = currentText1;
		currentText1 = currentText;
		currentText = Numbers->Text;

		textBox1->Text = textBox1->Text + Numbers->Text;
		digitLimit++;
	}

}

private: System::Void ABCDEF_Click(System::Object^ sender, System::EventArgs^ e) {	// wprowadzanie liter
	if (mode == 4)
	{
		Button^ Letters = safe_cast<Button^>(sender);	// pobieranie danych z przyciskow


		// poczatkowe warunki wprowadzania liczb/znakow ---------------
		if ((textBox1->Text == "0") & !(equalClick == 1))
		{

			
			textBox1->Text = Letters->Text;
			

			// zapisywanie aktualnych cyfr
			currentText6 = currentText5;
			currentText5 = currentText4;
			currentText4 = currentText3;
			currentText3 = currentText2;
			currentText2 = currentText1;
			currentText1 = currentText;
			currentText = Letters->Text;

		}
		// ------------------------------------------------------------


		else if ((digitLimit < 6) & !(equalClick == 1))
		{
			// zapisywanie wczesniejszych cyfr
			previousText6 = previousText5;
			previousText5 = previousText4;
			previousText4 = previousText3;
			previousText3 = previousText2;
			previousText2 = previousText1;
			previousText1 = previousText;
			previousText = textBox1->Text;

			// zapisywanie aktualnych cyfr
			currentText6 = currentText5;
			currentText5 = currentText4;
			currentText4 = currentText3;
			currentText3 = currentText2;
			currentText2 = currentText1;
			currentText1 = currentText;
			currentText = Letters->Text;

			textBox1->Text = textBox1->Text + Letters->Text;
			digitLimit++;
		}
	}
}

private: System::Void ClearAll(System::Object^ sender, System::EventArgs^ e) {	// wyczysc wszystko "C"

	textBox1->Text = "0";
	step = 0;
	digitLimit = 0;
	equalClick = 0;

	// zerowanie historycznie zapisanych znakow
	previousText6 = "0";
	previousText5 = "0";
	previousText4 = "0";
	previousText3 = "0";
	previousText2 = "0";
	previousText1 = "0";
	previousText = "0";
}
	   
	
public: System::Void MakePerCent(System::Object^ sender, System::EventArgs^ e) {	//obliczanie procentow
	
	if (!textBox1->Text->Contains("."))	//sprawdzanie czy tekst juz nie zawiera przecinkow
	{
		value = Double::Parse(textBox1->Text);
		percent = value * 0.01;
		textBox1->Text = System::Convert::ToString(percent);
	}

}
private: System::Void EnterOperator(System::Object^ sender, System::EventArgs^ e) {		// wprowadz operator

	Button^ NumbersOp = safe_cast<Button^>(sender);	// pobieranie danych z przyciskow


	// zapisywanie wartosci pierwszej z wprowadzonych cyfr - firstDigit - w zaleznosci od wybranego trybu konwertowanie cyfry na system dec przed zapisaniem do zmiennej firstDigit
	if (mode == 1)	// DEC
	{
		firstDigit = Double::Parse(textBox1->Text);
	}

	else if (mode == 2)	// BIN
	{
		firstDigit = Double::Parse(textBox1->Text);

		bin = firstDigit;

		while (bin != 0)
		{
			rem = bin % 10;
			bin = bin / 10;
			dec = dec + rem * pow(2, i);
			i++;
		}

		firstDigit = dec;
		dec = 0;
		bin = 0;
		oct = 0;
		hex = 0;
		i = 0;
	}

	else if (mode == 3)	// OCT
	{
		firstDigit = Double::Parse(textBox1->Text);

		oct = firstDigit;

		while (oct != 0)
		{
			rem = oct % 10;
			oct = oct / 10;
			dec = dec + rem * pow(8, i);
			i++;
		}

		firstDigit = dec;
		dec = 0;
		bin = 0;
		oct = 0;
		hex = 0;
		i = 0;
	}

	else if (mode == 4)	// HEX..								(CLI nie umozliwia wykorzystania tablic, wektorow, vector::push_back)
	{														//	wykorzystanie currentText jako alternatywa dla tablic i wektorow	

		if (equalClick == 1)
		{
			currentText6 = hex_str0;
			currentText5 = hex_str1;
			currentText4 = hex_str2;
			currentText3 = hex_str3;
			currentText2 = hex_str4;
			currentText1 = hex_str5;
			currentText = hex_str6;
		}
		else

		step = 0;

		if (currentText6 == "A")
		{
			hex0 = 10 * pow(16, step+6);
		}

		else if (currentText6 == "B")
		{
			hex0 = 11 * pow(16, step+6);
		}

		else if (currentText6 == "C")
		{
			hex0 = 12 * pow(16, step+6);
		}

		else if (currentText6 == "D")
		{
			hex0 = 13 * pow(16, step+6);
		}

		else if (currentText6 == "E")
		{
			hex0 = 14 * pow(16, step+6);
		}

		else if (currentText6 == "F")
		{
			hex0 = 15 * pow(16, step+6);
		}

		else if (!(currentText6 == ""))
		{
			hex0 = Double::Parse(currentText6) * pow(16, step + 6);
		}




		if (currentText5 == "A")
		{
			hex1 = 10 * pow(16, step+5);
		}

		else if (currentText5 == "B")
		{
			hex1 = 11 * pow(16, step+5);
		}

		else if (currentText5 == "C")
		{
			hex1 = 12 * pow(16, step+5);
		}

		else if (currentText5 == "D")
		{
			hex1 = 13 * pow(16, step+5);
		}

		else if (currentText5 == "E")
		{
			hex1 = 14 * pow(16, step+5);
		}

		else if (currentText5 == "F")
		{
			hex1 = 15 * pow(16, step+5);
		}

		else if (!(currentText5 == ""))
		{
			hex1 = Double::Parse(currentText5) * pow(16, step + 5);
		}



		if (currentText4 == "A")
		{
			hex2 = 10 * pow(16, step+4);
		}

		else if (currentText4 == "B")
		{
			hex2 = 11 * pow(16, step+4);
		}

		else if (currentText4 == "C")
		{
			hex2 = 12 * pow(16, step+4);
		}

		else if (currentText4 == "D")
		{
			hex2 = 13 * pow(16, step+4);
		}

		else if (currentText4 == "E")
		{
			hex2 = 14 * pow(16, step+4);
		}

		else if (currentText4 == "F")
		{
			hex2 = 15 * pow(16, step+4);
		}

		else if(!(currentText4 == ""))
		{
			hex2 = Double::Parse(currentText4) * pow(16, step + 4);
		}



		if (currentText3 == "A")
		{
			hex3 = 10 * pow(16, step+3);
		}

		else if (currentText3 == "B")
		{
			hex3 = 11 * pow(16, step+3);
		}

		else if (currentText3 == "C")
		{
			hex3 = 12 * pow(16, step+3);
		}

		else if (currentText3 == "D")
		{
			hex3 = 13 * pow(16, step+3);
		}

		else if (currentText3 == "E")
		{
			hex3 = 14 * pow(16, step+3);
		}

		else if (currentText3 == "F")
		{
			hex3 = 15 * pow(16, step+3);
		}

		else if (!(currentText3 == ""))
		{
			hex3 = Double::Parse(currentText3) * pow(16, step + 3);
		}



		if (currentText2 == "A")
		{
			hex4 = 10 * pow(16, step + 2);
		}

		else if (currentText2 == "B")
		{
			hex4 = 11 * pow(16, step + 2);
		}

		else if (currentText2 == "C")
		{
			hex4 = 12 * pow(16, step + 2);
		}

		else if (currentText2 == "D")
		{
			hex4 = 13 * pow(16, step + 2);
		}

		else if (currentText2 == "E")
		{
			hex4 = 14 * pow(16, step + 2);
		}

		else if (currentText2 == "F")
		{
			hex4 = 15 * pow(16, step + 2);
		}

		else if (!(currentText2 == ""))
		{
			hex4 = Double::Parse(currentText2) * pow(16, step + 2);
		}




		if (currentText1 == "A")
		{
			hex5 = 10 * pow(16, step+1);
		}

		else if (currentText1 == "B")
		{
			hex5 = 11 * pow(16, step+1);
		}

		else if (currentText1 == "C")
		{
			hex5 = 12 * pow(16, step+1);
		}

		else if (currentText1 == "D")
		{
			hex5 = 13 * pow(16, step+1);
		}

		else if (currentText1 == "E")
		{
			hex5 = 14 * pow(16, step+1);
		}

		else if (currentText1 == "F")
		{
			hex5 = 15 * pow(16, step+1);
		}

		else if (!(currentText1 == ""))
		{
			hex5 = Double::Parse(currentText1) * pow(16, step + 1);
		}




		if (currentText == "A")
		{
			hex6 = 10 * pow(16, step);
		}

		else if (currentText == "B")
		{
			hex6 = 11 * pow(16, step);
		}

		else if (currentText == "C")
		{
			hex6 = 12 * pow(16, step);
		}

		else if (currentText == "D")
		{
			hex6 = 13 * pow(16, step);
		}

		else if (currentText == "E")
		{
			hex6 = 14 * pow(16, step);
		}

		else if (currentText == "F")
		{
			hex6 = 15 * pow(16, step);
		}

		else if (!(currentText == ""))
		{
			hex6 = Double::Parse(currentText) * pow(16, step);
		}


		dec = hex6 + hex5 + hex4 + hex3 + hex2 + hex1 + hex0;	// konwersja liczb hex na system dec


		// zapisanie liczby jako firstDigit i zerowanie zmiennich pomocniczych - w tym currentText
		firstDigit = dec;
		dec = 0;
		bin = 0;
		oct = 0;
		hex = 0;
		hex0 = 0;
		hex1 = 0;
		hex2 = 0;
		hex3 = 0;
		hex4 = 0;
		hex5 = 0;
		hex6 = 0;
		i = 0;

		currentText6 = "0";
		currentText5 = "0";
		currentText4 = "0";
		currentText3 = "0";
		currentText2 = "0";
		currentText1 = "0";
		currentText = "0";

	}



	textBox1->Text = "";	// czyszczenie ekranu

	operators = NumbersOp->Text;	// zapisanie operatora

	// zerowanie limitu cyfr i kroku, detekcja znaku rownosci = 0
	digitLimit = 0;		
	step = 0;
	equalClick = 0;	

}
private: System::Void DotClick(System::Object^ sender, System::EventArgs^ e) {		// kropka (przecinek)

	if (equalClick == 1)
	{
		textBox1->Text = textBox1->Text + ",";
		digitLimit++;
	}

	if ((!textBox1->Text->Contains(",")) & (digitLimit < 6))
	{
		textBox1->Text = textBox1->Text + ",";
		digitLimit++;
	}
}
private: System::Void ClearEnter(System::Object^ sender, System::EventArgs^ e) {	// wyczysc ostatnia cyfre "CE"

	// po znaku rownosci dziala jak "C" - wyczysc wszystko
	if (equalClick == 1)
	{
		textBox1->Text = "0";
		equalClick = 0;
		step = 0;
		digitLimit = 0;

		previousText6 = "0";
		previousText5 = "0";
		previousText4 = "0";
		previousText3 = "0";
		previousText2 = "0";
		previousText1 = "0";
		previousText = "0";
	}

	// sciezka przywracania poprzedniego tekstu - usuwania ostatnio wprowadzonej cyfry
	else if (!(textBox1->Text == "0") & (step == 0))
	{
		textBox1->Text = previousText;
		step = 1;
		digitLimit--;
	}

	else if (!(textBox1->Text == "0") & (step == 1))
	{
		textBox1->Text = previousText1;
		step = 2;
		digitLimit--;
	}

	else if (!(textBox1->Text == "0") & (step == 2))
	{
		textBox1->Text = previousText2;
		step = 3;
		digitLimit--;
	}

	else if (!(textBox1->Text == "0") & (step == 3))
	{
		textBox1->Text = previousText3;
		step = 4;
		digitLimit--;
	}

	else if (!(textBox1->Text == "0") & (step == 4))
	{
		textBox1->Text = previousText4;
		step = 5;
		digitLimit--;
	}

	else if (!(textBox1->Text == "0") & (step == 5))
	{
		textBox1->Text = previousText5;
		step = 6;
		digitLimit--;
	}

	else if (!(textBox1->Text == "0") & (step == 6))
	{
		textBox1->Text = previousText6;
		digitLimit--;

	}

	// "cofanie sie" o jeden znak - poprzedni staje sie aktualnym
	currentText = currentText1;
	currentText1 = currentText2;
	currentText2 = currentText3;
	currentText3 = currentText4;
	currentText4 = currentText5;
	currentText5 = currentText6;


	// jesli wykasowanio wszystko - wyzeruj wszystkie zapisane znaki
	if (textBox1->Text == "0")
	{
		previousText6 = "0";
		previousText5 = "0";
		previousText4 = "0";
		previousText3 = "0";
		previousText2 = "0";
		previousText1 = "0";
		previousText = "0";

		currentText6 = "0";
		currentText5 = "0";
		currentText4 = "0";
		currentText3 = "0";
		currentText2 = "0";
		currentText1 = "0";
		currentText = "0";

		step = 0;
		digitLimit = 0;
		equalClick = 0;
	}
}

private: System::Void Equal(System::Object^ sender, System::EventArgs^ e) {		// obliczanie wprowadzonych liczb "="
	
	// zapisywanie wartosci drugiej z wprowadzonych cyfr - secondDigit - w zaleznosci od wybranego trybu konwertowanie cyfry na system dec przed zapisaniem do zmiennej secondDigit
	if (mode == 1)	// dla dec
	{
		secondDigit = Double::Parse(textBox1->Text);
	}

	else if (mode == 2)	// dla bin
	{
		secondDigit = Double::Parse(textBox1->Text);

		bin = secondDigit;

		while (bin != 0)
		{
			rem = bin % 10;
			bin = bin / 10;
			dec = dec + rem * pow(2, i);
			i++;
		}

		secondDigit = dec;
		dec = 0;
		bin = 0;
		oct = 0;
		hex = 0;
		i = 0;

	}

	else if (mode == 3)	// dla oct
	{
		secondDigit = Double::Parse(textBox1->Text);

		oct = secondDigit;

		while (oct != 0)
		{
			rem = oct % 10;
			oct = oct / 10;
			dec = dec + rem * pow(8, i);
			i++;
		}

		secondDigit = dec;
		dec = 0;
		bin = 0;
		oct = 0;
		hex = 0;
		i = 0;

	}

	else if (mode == 4)	// dla hex..
	{
		step = 0;

		if (currentText6 == "A")
		{
			hex0 = 10 * pow(16, step + 6);
		}

		else if (currentText6 == "B")
		{
			hex0 = 11 * pow(16, step + 6);
		}

		else if (currentText6 == "C")
		{
			hex0 = 12 * pow(16, step + 6);
		}

		else if (currentText6 == "D")
		{
			hex0 = 13 * pow(16, step + 6);
		}

		else if (currentText6 == "E")
		{
			hex0 = 14 * pow(16, step + 6);
		}

		else if (currentText6 == "F")
		{
			hex0 = 15 * pow(16, step + 6);
		}

		else
		{
			hex0 = Double::Parse(currentText6) * pow(16, step + 6);
		}




		if (currentText5 == "A")
		{
			hex1 = 10 * pow(16, step + 5);
		}

		else if (currentText5 == "B")
		{
			hex1 = 11 * pow(16, step + 5);
		}

		else if (currentText5 == "C")
		{
			hex1 = 12 * pow(16, step + 5);
		}

		else if (currentText5 == "D")
		{
			hex1 = 13 * pow(16, step + 5);
		}

		else if (currentText5 == "E")
		{
			hex1 = 14 * pow(16, step + 5);
		}

		else if (currentText5 == "F")
		{
			hex1 = 15 * pow(16, step + 5);
		}

		else
		{
			hex1 = Double::Parse(currentText5) * pow(16, step + 5);
		}



		if (currentText4 == "A")
		{
			hex2 = 10 * pow(16, step + 4);
		}

		else if (currentText4 == "B")
		{
			hex2 = 11 * pow(16, step + 4);
		}

		else if (currentText4 == "C")
		{
			hex2 = 12 * pow(16, step + 4);
		}

		else if (currentText4 == "D")
		{
			hex2 = 13 * pow(16, step + 4);
		}

		else if (currentText4 == "E")
		{
			hex2 = 14 * pow(16, step + 4);
		}

		else if (currentText4 == "F")
		{
			hex2 = 15 * pow(16, step + 4);
		}

		else
		{
			hex2 = Double::Parse(currentText4) * pow(16, step + 4);
		}



		if (currentText3 == "A")
		{
			hex3 = 10 * pow(16, step + 3);
		}

		else if (currentText3 == "B")
		{
			hex3 = 11 * pow(16, step + 3);
		}

		else if (currentText3 == "C")
		{
			hex3 = 12 * pow(16, step + 3);
		}

		else if (currentText3 == "D")
		{
			hex3 = 13 * pow(16, step + 3);
		}

		else if (currentText3 == "E")
		{
			hex3 = 14 * pow(16, step + 3);
		}

		else if (currentText3 == "F")
		{
			hex3 = 15 * pow(16, step + 3);
		}

		else
		{
			hex3 = Double::Parse(currentText3) * pow(16, step + 3);
		}



		if (currentText2 == "A")
		{
			hex4 = 10 * pow(16, step + 2);
		}

		else if (currentText2 == "B")
		{
			hex4 = 11 * pow(16, step + 2);
		}

		else if (currentText2 == "C")
		{
			hex4 = 12 * pow(16, step + 2);
		}

		else if (currentText2 == "D")
		{
			hex4 = 13 * pow(16, step + 2);
		}

		else if (currentText2 == "E")
		{
			hex4 = 14 * pow(16, step + 2);
		}

		else if (currentText2 == "F")
		{
			hex4 = 15 * pow(16, step + 2);
		}

		else
		{
			hex4 = Double::Parse(currentText2) * pow(16, step + 2);
		}




		if (currentText1 == "A")
		{
			hex5 = 10 * pow(16, step + 1);
		}

		else if (currentText1 == "B")
		{
			hex5 = 11 * pow(16, step + 1);
		}

		else if (currentText1 == "C")
		{
			hex5 = 12 * pow(16, step + 1);
		}

		else if (currentText1 == "D")
		{
			hex5 = 13 * pow(16, step + 1);
		}

		else if (currentText1 == "E")
		{
			hex5 = 14 * pow(16, step + 1);
		}

		else if (currentText1 == "F")
		{
			hex5 = 15 * pow(16, step + 1);
		}

		else
		{
			hex5 = Double::Parse(currentText1) * pow(16, step + 1);
		}




		if (currentText == "A")
		{
			hex6 = 10 * pow(16, step);
		}

		else if (currentText == "B")
		{
			hex6 = 11 * pow(16, step);
		}

		else if (currentText == "C")
		{
			hex6 = 12 * pow(16, step);
		}

		else if (currentText == "D")
		{
			hex6 = 13 * pow(16, step);
		}

		else if (currentText == "E")
		{
			hex6 = 14 * pow(16, step);
		}

		else if (currentText == "F")
		{
			hex6 = 15 * pow(16, step);
		}

		else
		{
			hex6 = Double::Parse(currentText) * pow(16, step);
		}


		dec = hex6 + hex5 + hex4 + hex3 + hex2 + hex1 + hex0;



		secondDigit = dec;
		dec = 0;
		bin = 0;
		oct = 0;
		hex = 0;
		hex0 = 0;
		hex1 = 0;
		hex2 = 0;
		hex3 = 0;
		hex4 = 0;
		hex5 = 0;
		hex6 = 0;
		i = 0;


		currentText6 = "0";
		currentText5 = "0";
		currentText4 = "0";
		currentText3 = "0";
		currentText2 = "0";
		currentText1 = "0";
		currentText = "0";

	}

	equalClick = 1;
	digitLimit = 0;
	step = 0;

	previousText6 = "0";
	previousText5 = "0";
	previousText4 = "0";
	previousText3 = "0";
	previousText2 = "0";
	previousText1 = "0";
	previousText = "0";




// sekcja obliczania i wyswietlania wyniku -----------------------------------------------------------------------------------------------------------------------

	// sprawdzanie ktory operator zostal wprowadzony
	// konwersja liczby zapisanej w systemie dec na system bin, oct, hex w zaleznosci od wybranego trybu
	// wyswietlanie wyniku

	if (operators == "+")
	{
		result = firstDigit + secondDigit;

		if (mode == 1)	// dla dec
		{
			textBox1->Text = System::Convert::ToString(result);
		}

		if (mode == 2)	// dla bin
		{
			dec = result;
			textBox1->Text = "0";

			while (dec > 0)	// konwersja decymalnego na binarny
			{

				bin = dec % 2;
				save_bit(i, System::Convert::ToString(bin));
				dec = dec / 2;
				i = i + 1;
			}
			i = 0;


			clear_zeros();

			textBox1->Text = previousText6 + previousText5 + previousText4 + previousText3 + previousText2 + previousText1 + previousText;	// odwrotna kolejnosc

		}

		if (mode == 3)	// dla oct
		{
			dec = result;
			textBox1->Text = "0";

			while (dec > 0)	// konwersja decymalnego na oktagonalny
			{

				oct = dec % 8;
				save_bit(i, System::Convert::ToString(oct));
				dec = dec / 8;
				i = i + 1;
			}
			i = 0;


			clear_zeros();

			textBox1->Text = previousText6 + previousText5 + previousText4 + previousText3 + previousText2 + previousText1 + previousText;	// odwrotna kolejnosc

		}

	}

	else if (operators == "-")
	{
		result = firstDigit - secondDigit;

		if (mode == 1)	// dla dec
		{
			textBox1->Text = System::Convert::ToString(result);
		}

		if (mode == 2)	// dla bin
		{
			dec = result;
			textBox1->Text = "0";

			while (dec > 0)	// konwersja decymalnego na binarny
			{

				bin = dec % 2;
				save_bit(i, System::Convert::ToString(bin));
				dec = dec / 2;
				i = i + 1;
			}
			i = 0;


			clear_zeros();

			textBox1->Text = previousText6 + previousText5 + previousText4 + previousText3 + previousText2 + previousText1 + previousText; // odwrotna kolejnosc

		}

		if (mode == 3)	// dla oct
		{
			dec = result;
			textBox1->Text = "0";

			while (dec > 0)	// konwersja decymalnego na oktagonalny
			{

				oct = dec % 8;
				save_bit(i, System::Convert::ToString(oct));
				dec = dec / 8;
				i = i + 1;
			}
			i = 0;


			clear_zeros();

			textBox1->Text = previousText6 + previousText5 + previousText4 + previousText3 + previousText2 + previousText1 + previousText;	// odwrotna kolejnosc

		}

	}

	else if (operators == "�")
	{
		result = firstDigit / secondDigit;

		if (mode == 1)	// dla dec
		{
			textBox1->Text = System::Convert::ToString(result);
		}

		if (mode == 2)	// dla bin
		{
			dec = result;
			textBox1->Text = "0";

			while (dec > 0)	// konwersja decymalnego na binarny
			{

				bin = dec % 2;
				save_bit(i, System::Convert::ToString(bin));
				dec = dec / 2;
				i = i + 1;
			}
			i = 0;


			clear_zeros();

			textBox1->Text = previousText6 + previousText5 + previousText4 + previousText3 + previousText2 + previousText1 + previousText; 

		}

		if (mode == 3)	// dla oct
		{
			dec = result;
			textBox1->Text = "0";

			while (dec > 0)	// konwersja decymalnego na oktagonalny
			{

				oct = dec % 8;
				save_bit(i, System::Convert::ToString(oct));
				dec = dec / 8;
				i = i + 1;
			}
			i = 0;


			clear_zeros();

			textBox1->Text = previousText6 + previousText5 + previousText4 + previousText3 + previousText2 + previousText1 + previousText;	

		}

	}

	else if (operators == "�")
	{
		result = firstDigit * secondDigit;

		if (mode == 1)	// dla dec
		{
			textBox1->Text = System::Convert::ToString(result);
		}

		if (mode == 2)	// dla bin
		{
			dec = result;
			textBox1->Text = "0";

			while (dec > 0)	// konwersja decymalnego na binarny
			{

				bin = dec % 2;
				save_bit(i, System::Convert::ToString(bin));
				dec = dec / 2;
				i = i + 1;
			}
			i = 0;


			clear_zeros();

			textBox1->Text = previousText6 + previousText5 + previousText4 + previousText3 + previousText2 + previousText1 + previousText;

		}

		if (mode == 3)	// dla oct
		{
			dec = result;
			textBox1->Text = "0";

			while (dec > 0)	// konwersja decymalnego na oktagonalny
			{

				oct = dec % 8;
				save_bit(i, System::Convert::ToString(oct));
				dec = dec / 8;
				i = i + 1;
			}
			i = 0;


			clear_zeros();

			textBox1->Text = previousText6 + previousText5 + previousText4 + previousText3 + previousText2 + previousText1 + previousText;	

		}

	}


	if (mode == 4) // dla hex..
	{
		dec = result;
		textBox1->Text = "0";
		i = 1;
		hex = 0;
		hex0 = 0;

		while (1)
		{
			hex = hex + pow(16, 6);

			if (hex >= dec)
			{
				hex = hex - pow(16, 6);
				break;
			}
			else
			{
				hex0 = i;
				i++;
			}
		}
		i = 1;
		hex1 = 0;

		while (1)
		{
			hex = hex + pow(16, 5);

			if (hex >= dec)
			{

				hex = hex - pow(16, 5);
				break;
			}
			else
			{
				hex1 = i;
				i++;
			}
		}
		i = 1;
		hex2 = 0;

		while (1)
		{
			hex = hex + pow(16, 4);

			if (hex >= dec)
			{
				hex = hex - pow(16, 4);
				break;
			}
			else
			{
				hex2 = i;
				i++;
			}
		}
		i = 1;
		hex3 = 0;

		while (1)
		{
			hex = hex + pow(16, 3);

			if (hex >= dec)
			{
				hex = hex - pow(16, 3);
				break;
			}
			else
			{
				hex3 = i;
				i++;
			}
		}
		i = 1;
		hex4 = 0;

		while (1)
		{
			hex = hex + pow(16, 2);

			if (hex >= dec)
			{
				hex = hex - pow(16, 2);
				break;
			}
			else
			{
				hex4 = i;
				i++;
			}
		}
		i = 1;
		hex5 = 0;

		while (1)
		{
			hex = hex + pow(16, 1);

			if (hex >= dec)
			{
				hex = hex - pow(16, 1);
				break;
			}
			else
			{
				hex5 = i;
				i++;
			}
		}
		i = 1;
		hex6 = 0;

		while (1)
		{
			hex = hex + pow(16, 0);

			if (hex == dec)
			{
				hex = hex - pow(16, 0);
				hex6 = i;
				break;
			}
			else
			{
				i++;
			}
		}
		i = 0;
		hex = 0;


		// zamiana cyfr wiekszych od 10 na litery
		switch (hex6)
		{
		case 10:
			hex_str6 = "A";
			break;

		case 11:
			hex_str6 = "B";
			break;

		case 12:
			hex_str6 = "C";
			break;

		case 13:
			hex_str6 = "D";
			break;

		case 14:
			hex_str6 = "E";
			break;

		case 15:
			hex_str6 = "F";
			break;

		default:
			hex_str6 = System::Convert::ToString(hex6);
		}



		switch (hex5)
		{
		case 10:
			hex_str5 = "A";
			break;

		case 11:
			hex_str5 = "B";
			break;

		case 12:
			hex_str5 = "C";
			break;

		case 13:
			hex_str5 = "D";
			break;

		case 14:
			hex_str5 = "E";
			break;

		case 15:
			hex_str5 = "F";
			break;

		default:
			hex_str5 = System::Convert::ToString(hex5);
		}


		switch (hex4)
		{
		case 10:
			hex_str4 = "A";
			break;

		case 11:
			hex_str4 = "B";
			break;

		case 12:
			hex_str4 = "C";
			break;

		case 13:
			hex_str4 = "D";
			break;

		case 14:
			hex_str4 = "E";
			break;

		case 15:
			hex_str4 = "F";
			break;

		default:
			hex_str4 = System::Convert::ToString(hex4);
		}



		switch (hex3)
		{
		case 10:
			hex_str3 = "A";
			break;

		case 11:
			hex_str3 = "B";
			break;

		case 12:
			hex_str3 = "C";
			break;

		case 13:
			hex_str3 = "D";
			break;

		case 14:
			hex_str3 = "E";
			break;

		case 15:
			hex_str3 = "F";
			break;

		default:
			hex_str3 = System::Convert::ToString(hex3);
		}


		switch (hex2)
		{
		case 10:
			hex_str2 = "A";
			break;

		case 11:
			hex_str2 = "B";
			break;

		case 12:
			hex_str2 = "C";
			break;

		case 13:
			hex_str2 = "D";
			break;

		case 14:
			hex_str2 = "E";
			break;

		case 15:
			hex_str2 = "F";
			break;

		default:
			hex_str2 = System::Convert::ToString(hex2);
		}


		switch (hex1)
		{
		case 10:
			hex_str1 = "A";
			break;

		case 11:
			hex_str1 = "B";
			break;

		case 12:
			hex_str1 = "C";
			break;

		case 13:
			hex_str1 = "D";
			break;

		case 14:
			hex_str1 = "E";
			break;

		case 15:
			hex_str1 = "F";
			break;

		default:
			hex_str1 = System::Convert::ToString(hex1);
		}



		switch (hex0)
		{
		case 10:
			hex_str0 = "A";
			break;

		case 11:
			hex_str0 = "B";
			break;

		case 12:
			hex_str0 = "C";
			break;

		case 13:
			hex_str0 = "D";
			break;

		case 14:
			hex_str0 = "E";
			break;

		case 15:
			hex_str0 = "F";
			break;

		default:
			hex_str0 = System::Convert::ToString(hex0);
		}


		// usuwanie zer przed pierwsza cyfra znaczaca - dla hex
		if (hex_str0 == "0" & !(hex_str1 == "0"))
		{
			hex_str0 = "";
		}
		else if (hex_str0 == "0" & hex_str1 == "0" & !(hex_str2 == "0"))
		{
			hex_str0 = "";
			hex_str1 = "";
		}
		else if (hex_str0 == "0" & hex_str1 == "0" & hex_str2 == "0" & !(hex_str3 == "0"))
		{
			hex_str0 = "";
			hex_str1 = "";
			hex_str2 = "";
		}
		else if (hex_str0 == "0" & hex_str1 == "0" & hex_str2 == "0" & hex_str3 == "0" & !(hex_str4 == "0"))
		{
			hex_str0 = "";
			hex_str1 = "";
			hex_str2 = "";
			hex_str3 = "";
		}
		else if (hex_str0 == "0" & hex_str1 == "0" & hex_str2 == "0" & hex_str3 == "0" & hex_str4 == "0" & !(hex_str5 == "0"))
		{
			hex_str0 = "";
			hex_str1 = "";
			hex_str2 = "";
			hex_str3 = "";
			hex_str4 = "";
		}
		else if (hex_str0 == "0" & hex_str1 == "0" & hex_str2 == "0" & hex_str3 == "0" & hex_str4 == "0" & hex_str5 == "0" & !(hex_str6 == "0"))
		{
			hex_str0 = "";
			hex_str1 = "";
			hex_str2 = "";
			hex_str3 = "";
			hex_str4 = "";
			hex_str5 = "";
		}


		textBox1->Text = hex_str0 + hex_str1 + hex_str2 + hex_str3 + hex_str4 + hex_str5 + hex_str6;

	}

	// koniec sekcji obliczania i wyswietlania wyniku ------------------------------------------------------------------------------------------------------------
}



private: System::Void float_click(System::Object^ sender, System::EventArgs^ e) {
	mode = 1;
}

private: System::Void bin_click(System::Object^ sender, System::EventArgs^ e) {
	mode = 2;
}

private: System::Void oct_click(System::Object^ sender, System::EventArgs^ e) {
	mode = 3;
}

private: System::Void hex_click(System::Object^ sender, System::EventArgs^ e) {
	mode = 4;
}
private: System::Void button26_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void button29_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void treeView1_AfterSelect(System::Object^ sender, System::Windows::Forms::TreeViewEventArgs^ e) {
}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void button18_Click(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void button14_Click(System::Object^ sender, System::EventArgs^ e) {
}


};
}
